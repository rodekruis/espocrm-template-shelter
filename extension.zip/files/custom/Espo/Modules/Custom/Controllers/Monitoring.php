<?php

namespace Espo\Modules\Custom\Controllers;

class Monitoring extends \Espo\Core\Templates\Controllers\Base
{}
