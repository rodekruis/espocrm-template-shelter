<?php

namespace Espo\Modules\Custom\Controllers;

class AdequacyCriteria extends \Espo\Core\Templates\Controllers\Base
{}
