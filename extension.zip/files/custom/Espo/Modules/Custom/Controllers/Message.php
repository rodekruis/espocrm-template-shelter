<?php

namespace Espo\Modules\Custom\Controllers;

class Message extends \Espo\Core\Templates\Controllers\Base
{}
