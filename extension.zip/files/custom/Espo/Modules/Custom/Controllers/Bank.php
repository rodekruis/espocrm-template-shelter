<?php

namespace Espo\Modules\Custom\Controllers;

class Bank extends \Espo\Core\Templates\Controllers\Base
{}
