<?php

namespace Espo\Modules\Custom\Controllers;

class AffectedHousehold extends \Espo\Core\Templates\Controllers\Base
{}
