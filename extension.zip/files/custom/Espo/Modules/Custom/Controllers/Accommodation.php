<?php

namespace Espo\Modules\Custom\Controllers;

class Accommodation extends \Espo\Core\Templates\Controllers\Base
{}
