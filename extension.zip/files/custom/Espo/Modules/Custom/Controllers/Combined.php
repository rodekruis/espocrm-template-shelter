<?php

namespace Espo\Modules\Custom\Controllers;

class Combined extends \Espo\Core\Templates\Controllers\Base
{}
