<?php

namespace Espo\Modules\Custom\Controllers;

class MessageTemplate extends \Espo\Core\Templates\Controllers\Base
{}
