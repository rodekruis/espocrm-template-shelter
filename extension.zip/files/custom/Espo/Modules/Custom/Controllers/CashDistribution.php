<?php

namespace Espo\Modules\Custom\Controllers;

class CashDistribution extends \Espo\Core\Templates\Controllers\Base
{}
