<?php

namespace Espo\Modules\Custom\Controllers;

class Transfer extends \Espo\Core\Templates\Controllers\Base
{}
