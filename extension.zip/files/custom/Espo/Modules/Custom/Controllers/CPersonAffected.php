<?php

namespace Espo\Modules\Custom\Controllers;

class CPersonAffected extends \Espo\Core\Templates\Controllers\Base
{}
