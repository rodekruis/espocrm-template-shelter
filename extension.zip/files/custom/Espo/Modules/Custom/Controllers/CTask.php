<?php

namespace Espo\Modules\Custom\Controllers;

class CTask extends \Espo\Core\Templates\Controllers\Base
{}
